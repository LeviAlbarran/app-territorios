app.directive("informacionMarkers", function(){
   return {
      template:"<button ng-click='function1()'></div>"
   };
});